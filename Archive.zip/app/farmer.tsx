"use client"

import { useEffect, useState } from "react"
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  ScrollView,
  Dimensions,
  SafeAreaView,
  FlatList,
} from "react-native"
import * as ImagePicker from "expo-image-picker"
import { Ionicons } from "@expo/vector-icons"
import type { NavigationProp, ParamListBase } from "@react-navigation/native"
import { format } from "date-fns";
import React from "react"
import { db } from "../firebaseConfig"; // Adjust path if needed
import { collection, onSnapshot } from "firebase/firestore";

interface GrowingItem {
  id: string
  name: string
  plantedDate: Date
  expectedHarvest: Date
  quantity: number
  notes: string
}

interface Product {
  id: string
  name: string
  price: number
  count: number
  image: string
  isDiscounted?: boolean
}

interface Order {
  id: string
  productId: string
  quantity: number
  status: "pending" | "delivered"
}

interface Props {
  navigation: NavigationProp<ParamListBase>
}

const SCREEN_WIDTH = Dimensions.get("window").width
const CARD_MARGIN = 10
const CARD_WIDTH = (SCREEN_WIDTH - 3 * CARD_MARGIN) / 2

// Placeholder for logout function
const logout = async () => {
  // Implement your logout logic here
  console.log("Logging out...")
}
const fetchProducts = () => {
  useEffect(() => {
  const unsubscribe = onSnapshot(collection(db, "products"), (querySnapshot) => {
    const itemList: any[] = [];
    querySnapshot.forEach((doc) => {
      itemList.push({ id: doc.id, ...doc.data() });
    });
    console.log("Fetched products:", itemList);
  });
  return () => unsubscribe(); 
}, []);
};

export default function FarmerScreen({ navigation }: Props) {
  const [modalVisible, setModalVisible] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [productName, setProductName] = useState<string>("")
  const [productPrice, setProductPrice] = useState<string>("")
  const [productCount, setProductCount] = useState<string>("")
  const [productImage, setProductImage] = useState<string | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [activeTab, setActiveTab] = useState<"home" | "products" | "discounted" | "ai" | "weather">("home")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [showScheduledModal, setShowScheduledModal] = useState(false)

  const resetForm = () => {
    setProductName("")
    setProductPrice("")
    setProductCount("")
    setProductImage(null)
    setEditingProduct(null)
  }

  const [growingItems, setGrowingItems] = useState<GrowingItem[]>([
    {
      id: '1',
      name: 'Tomatoes',
      plantedDate: new Date('2025-01-15'),
      expectedHarvest: new Date('2025-03-15'),
      quantity: 100,
      notes: 'Cherry variety, greenhouse'
    },
    {
      id: '2',
      name: 'Lettuce',
      plantedDate: new Date('2025-02-01'),
      expectedHarvest: new Date('2025-03-01'),
      quantity: 200,
      notes: 'Romaine, outdoor beds'
    }
  ])
  const [showGrowingModal, setShowGrowingModal] = useState(false)
  const [newGrowingItem, setNewGrowingItem] = useState<Partial<GrowingItem>>({})

  const handleAddGrowingItem = () => {
    if (!newGrowingItem.name || !newGrowingItem.plantedDate || !newGrowingItem.expectedHarvest || !newGrowingItem.quantity) {
      Alert.alert("Error", "Please fill in all required fields")
      return
    }

    const newItem: GrowingItem = {
      id: Math.random().toString(),
      name: newGrowingItem.name,
      plantedDate: new Date(newGrowingItem.plantedDate),
      expectedHarvest: new Date(newGrowingItem.expectedHarvest),
      quantity: Number(newGrowingItem.quantity),
      notes: newGrowingItem.notes || ''
    }

    setGrowingItems([...growingItems, newItem])
    setShowGrowingModal(false)
    setNewGrowingItem({})
  }

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setProductName(product.name)
    setProductPrice(product.price.toString())
    setProductCount(product.count.toString())
    setProductImage(product.image)
    setModalVisible(true)
  }

  const handleDelete = (id: string) => {
    Alert.alert("Delete Product", "Are you sure you want to delete this product?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      {
        text: "Delete",
        onPress: () => {
          setProducts(products.filter((product) => product.id !== id))
        },
      },
    ])
  }

  const handleAddProduct = () => {
    if (!productName || !productPrice || !productCount || !productImage) {
      Alert.alert("Error", "Please fill in all fields and select an image.")
      return
    }

    const newProduct: Product = {
      id: Math.random().toString(),
      name: productName,
      price: Number.parseFloat(productPrice),
      count: Number.parseInt(productCount),
      image: productImage,
      isDiscounted: false,
    }

    setProducts([...products, newProduct])
    setModalVisible(false)
    resetForm()
  }

  const handleUpdateProduct = () => {
    if (!productName || !productPrice || !productCount || !productImage || !editingProduct) {
      Alert.alert("Error", "Please fill in all fields and select an image.")
      return
    }

    const updatedProduct: Product = {
      ...editingProduct,
      name: productName,
      price: Number.parseFloat(productPrice),
      count: Number.parseInt(productCount),
      image: productImage,
    }

    setProducts(products.map((product) => (product.id === updatedProduct.id ? updatedProduct : product)))
    setModalVisible(false)
    resetForm()
  }

  const toggleDiscount = (productId: string) => {
    setProducts(
      products.map((product) =>
        product.id === productId ? { ...product, isDiscounted: !product.isDiscounted } : product,
      ),
    )
  }

  const renderHomeTab = () => (
    <ScrollView>
      <Text style={styles.homeText}>Here's your daily summary:</Text>
      <View style={styles.summaryCard}>
      <Text style={styles.summaryTitle}>Inventory</Text>
        <Text style={styles.summaryItem}>Total Products: {products.length}</Text>
        <Text style={styles.summaryItem}>Total Stock: {products.reduce((sum, product) => sum + product.count, 0)}</Text>
        <Text style={styles.summaryItem}>Latest Product: {products[products.length - 1]?.name || "N/A"}</Text>
      </View>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Sales Overview</Text>
        <Text style={styles.summaryItem}>Total Sales: $1,234.56</Text>
        <Text style={styles.summaryItem}>Best Selling Product: Product A</Text>
      </View>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Low Stock Alerts</Text>
        {products
          .filter((p) => p.count < 5)
          .map((p) => (
            <Text key={p.id} style={styles.alertItem}>
              {p.name}: Only {p.count} left!
            </Text>
          ))}
      </View>
      
{/* Growing Items Section */}
<View style={styles.summaryCard}>
      <View style={styles.growingHeaderContainer}>
        <Text style={styles.summaryTitle}>Currently Growing</Text>
        <TouchableOpacity 
          style={styles.addGrowingButton}
          onPress={() => setShowGrowingModal(true)}
        >
          <Ionicons name="add-circle" size={24} color="#4CAF50" />
        </TouchableOpacity>
      </View>
      
      {growingItems.length === 0 ? (
        <Text style={styles.noItemsText}>No crops currently growing</Text>
      ) : (
        growingItems.map((item) => (
          <View key={item.id} style={styles.growingItemCard}>
            <View style={styles.growingItemHeader}>
              <Text style={styles.growingItemName}>{item.name}</Text>
              <Text style={styles.growingItemQuantity}>{item.quantity} plants</Text>
            </View>
            <View style={styles.growingItemDates}>
              <Text style={styles.dateText}>
                Planted: {format(new Date(item.plantedDate), 'MMM dd, yyyy')}
              </Text>
              <Text style={styles.dateText}>
                Expected Harvest: {format(new Date(item.expectedHarvest), 'MMM dd, yyyy')}
              </Text>
            </View>
            {item.notes && (
              <Text style={styles.growingItemNotes}>{item.notes}</Text>
            )}
          </View>
        ))
      )}
    </View>

    {/* Growing Items Modal */}
    <Modal
      animationType="slide"
      transparent={true}
      visible={showGrowingModal}
      onRequestClose={() => setShowGrowingModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalView}>
          <Text style={styles.modalTitle}>Add New Growing Item</Text>
          
          <TextInput
            style={styles.modalInput}
            placeholder="Crop Name"
            value={newGrowingItem.name}
            onChangeText={(text) => setNewGrowingItem({...newGrowingItem, name: text})}
          />

          <TextInput
            style={styles.modalInput}
            placeholder="Quantity"
            keyboardType="numeric"
            value={newGrowingItem.quantity?.toString()}
            onChangeText={(text) => setNewGrowingItem({...newGrowingItem, quantity: parseInt(text) || 0})}
          />

          <Text style={styles.inputLabel}>Planting Date:</Text>
          <TextInput
            style={styles.modalInput}
            placeholder="YYYY-MM-DD"
            value={newGrowingItem.plantedDate?.toISOString().split('T')[0]}
            onChangeText={(text) => {
              const date = new Date(text);
              if (!isNaN(date.getTime())) {
                setNewGrowingItem({...newGrowingItem, plantedDate: date});
              }
            }}
          />

          <Text style={styles.inputLabel}>Expected Harvest Date:</Text>
          <TextInput
            style={styles.modalInput}
            placeholder="YYYY-MM-DD"
            value={newGrowingItem.expectedHarvest?.toISOString().split('T')[0]}
            onChangeText={(text) => {
              const date = new Date(text);
              if (!isNaN(date.getTime())) {
                setNewGrowingItem({...newGrowingItem, expectedHarvest: date});
              }
            }}
          />

          <TextInput
            style={[styles.modalInput, styles.notesInput]}
            placeholder="Notes (optional)"
            multiline
            value={newGrowingItem.notes}
            onChangeText={(text) => setNewGrowingItem({...newGrowingItem, notes: text})}
          />

          <View style={styles.modalButtonContainer}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={() => {
                setShowGrowingModal(false);
                setNewGrowingItem({});
              }}
            >
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.saveButton]}
              onPress={handleAddGrowingItem}
            >
              <Text style={styles.modalButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>

    </ScrollView>
  )

  const renderProductsTab = (showDiscounted: boolean) => {
    const filteredProducts = products.filter((product) => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesDiscount = product.isDiscounted === showDiscounted
      return matchesSearch && matchesDiscount
    })

    return (
      <>
        <Text style={styles.sectionTitle}>{showDiscounted ? "Discounted Products" : "My Products"}</Text>
        <TextInput
          style={styles.searchBar}
          placeholder="Search for products..."
          placeholderTextColor="#FFA500"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {filteredProducts.length === 0 ? (
          <Text style={styles.noResultsText}>No products found</Text>
        ) : (
          <FlatList
            data={filteredProducts}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.productCard}>
                <Image source={{ uri: item.image }} style={styles.productImage} />
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{item.name}</Text>
                  <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
                  <Text style={styles.productCount}>Stock: {item.count}</Text>
                  {item.isDiscounted && (
                    <View style={styles.discountSticker}>
                      <Text style={styles.discountText}>Discounted</Text>
                    </View>
                  )}
                  <View style={styles.cardButtonContainer}>
                    <TouchableOpacity style={[styles.cardButton, styles.editButton]} onPress={() => handleEdit(item)}>
                      <Ionicons name="pencil" size={16} color="#FFF" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.cardButton, styles.deleteButton]}
                      onPress={() => handleDelete(item.id)}
                    >
                      <Ionicons name="trash" size={16} color="#FFF" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[
                        styles.cardButton,
                        item.isDiscounted ? styles.removeDiscountButton : styles.discountButton,
                      ]}
                      onPress={() => toggleDiscount(item.id)}
                    >
                      <Ionicons name={item.isDiscounted ? "close-circle" : "pricetag"} size={16} color="#FFF" />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
          />
        )}
        {!showDiscounted && (
          <TouchableOpacity
            style={styles.addNewButton}
            onPress={() => {
              resetForm()
              setModalVisible(true)
            }}
          >
            <Ionicons name="add-circle" size={24} color="#FFF" />
            <Text style={styles.addNewText}>Add New Product</Text>
          </TouchableOpacity>
        )}
      </>
    )
  }

  const renderAIAnalysisTab = () => (
    <View style={styles.aiContainer}>
      <Text style={styles.sectionTitle}>AI Analysis</Text>
      <Text style={styles.aiText}>Based on your sales data and market trends, here are some insights:</Text>
      <View style={styles.aiCard}>
        <Text style={styles.aiInsight}>1. Consider increasing the stock of Product B by 20%.</Text>
        <Text style={styles.aiInsight}>2. Tomatoes are trending. Consider adding them to your inventory.</Text>
        <Text style={styles.aiInsight}>3. Sales of Product C drop during summer. Plan accordingly.</Text>
      </View>
    </View>
  )

  const renderWeatherTab = () => (
    <ScrollView>
      <View style={styles.weatherContainer}>
        <View style={styles.currentWeatherCard}>
          <Text style={styles.sectionTitle}>Current Weather</Text>
          <View style={styles.weatherInfo}>
            <Ionicons name="partly-sunny" size={40} color="#FFA500" />
            <View style={styles.weatherDetails}>
              <Text style={styles.temperature}>75°F | Partly Cloudy</Text>
              <Text style={styles.humidity}>Humidity: 65%</Text>
              <Text style={styles.windSpeed}>Wind: 8 mph NE</Text>
            </View>
          </View>
        </View>
  
        <View style={styles.alertCard}>
          <Text style={styles.cardTitle}>
            <Ionicons name="warning-outline" size={24} color="#FF4136" style={styles.cardIcon} />
            Weather Alerts
          </Text>
          <View style={styles.alertItem}>
            <Text style={styles.alertTitle}>Frost Warning</Text>
            <Text style={styles.alertDescription}>
              Expected tonight. Protect sensitive crops with frost blankets.
            </Text>
          </View>
          <View style={styles.alertItem}>
            <Text style={styles.alertTitle}>Heavy Rain Alert</Text>
            <Text style={styles.alertDescription}>
              80% chance of heavy rainfall tomorrow. Secure young plants and ensure proper drainage.
            </Text>
          </View>
        </View>
  
        <View style={styles.cropRecommendationCard}>
          <Text style={styles.cardTitle}>
            <Ionicons name="leaf-outline" size={24} color="#28A745" style={styles.cardIcon} />
            Crop Recommendations
          </Text>
          <View style={styles.recommendationItem}>
            <Text style={styles.cropType}>Root Vegetables</Text>
            <Text style={styles.recommendationText}>
              • Ideal time to plant carrots and potatoes
              • Soil temperature optimal at 65°F
            </Text>
          </View>
          <View style={styles.recommendationItem}>
            <Text style={styles.cropType}>Tomatoes</Text>
            <Text style={styles.recommendationText}>
              • Move sensitive varieties to greenhouse
              • Add extra mulch for frost protection
            </Text>
          </View>
          <View style={styles.recommendationItem}>
            <Text style={styles.cropType}>Leafy Greens</Text>
            <Text style={styles.recommendationText}>
              • Cover lettuce beds before frost
              • Monitor soil moisture due to incoming rain
            </Text>
          </View>
        </View>
  
        <View style={styles.forecastCard}>
          <Text style={styles.cardTitle}>
            <Ionicons name="calendar-outline" size={24} color="#0074D9" style={styles.cardIcon} />
            3-Day Forecast
          </Text>
          <View style={styles.forecastContainer}>
            <View style={styles.forecastDay}>
              <Text style={styles.dayText}>Today</Text>
              <Ionicons name="partly-sunny" size={30} color="#FFA500" />
              <Text style={styles.tempText}>75°F</Text>
              <Text style={styles.weatherText}>Partly Cloudy</Text>
            </View>
            <View style={styles.forecastDay}>
              <Text style={styles.dayText}>Tomorrow</Text>
              <Ionicons name="rainy" size={30} color="#0074D9" />
              <Text style={styles.tempText}>68°F</Text>
              <Text style={styles.weatherText}>Heavy Rain</Text>
            </View>
            <View style={styles.forecastDay}>
              <Text style={styles.dayText}>Monday</Text>
              <Ionicons name="sunny" size={30} color="#FFA500" />
              <Text style={styles.tempText}>72°F</Text>
              <Text style={styles.weatherText}>Clear</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  )

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    })

    if (!result.canceled) {
      setProductImage(result.assets[0].uri)
    }
  }

  const handleLogout = async () => {
    await logout()
    // Navigate to login page
    navigation.navigate("Login")
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Welcome, Farmer Alex!</Text>
        <View style={styles.iconContainer}>
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowScheduledModal(true)}>
            <Ionicons name="calendar" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton} onPress={handleLogout}>
            <Ionicons name="log-out" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Navigation Menu */}
      <View style={styles.navMenu}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {["home", "products", "discounted", "ai", "weather"].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.navItem, activeTab === tab && styles.activeNavItem]}
              onPress={() => setActiveTab(tab as typeof activeTab)}
            >
              <Text style={[styles.navText, activeTab === tab && styles.activeNavText]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Main Content */}
      <View style={styles.mainContent}>
        {activeTab === "home" && renderHomeTab()}
        {activeTab === "products" && renderProductsTab(false)}
        {activeTab === "discounted" && renderProductsTab(true)}
        {activeTab === "ai" && renderAIAnalysisTab()}
        {activeTab === "weather" && renderWeatherTab()}
      </View>

      {/* Add/Edit Product Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible)
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalView}>
            <Text style={styles.modalTitle}>{editingProduct ? "Edit Product" : "Add New Product"}</Text>
            <TouchableOpacity onPress={pickImage} style={styles.imagePicker}>
              {productImage ? (
                <Image source={{ uri: productImage }} style={styles.modalImage} />
              ) : (
                <View style={[styles.modalImage, styles.placeholderImage]}>
                  <Ionicons name="camera" size={30} color="#28A745" />
                  <Text style={styles.placeholderText}>Tap to select image</Text>
                </View>
              )}
            </TouchableOpacity>
            <TextInput
              style={styles.modalInput}
              placeholder="Product Name"
              placeholderTextColor="#888"
              value={productName}
              onChangeText={setProductName}
              returnKeyType="done"
            />
            <TextInput
              style={styles.modalInput}
              placeholder="Price"
              placeholderTextColor="#888"
              value={productPrice}
              onChangeText={setProductPrice}
              keyboardType="numeric"
              returnKeyType="done"
            />
            <TextInput
              style={styles.modalInput}
              placeholder="Stock"
              placeholderTextColor="#888"
              value={productCount}
              onChangeText={setProductCount}
              keyboardType="numeric"
              returnKeyType="done"
            />
            <View style={styles.modalButtonContainer}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={editingProduct ? handleUpdateProduct : handleAddProduct}
              >
                <Text style={styles.modalButtonText}>{editingProduct ? "Update" : "Add"}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Scheduled Items Modal */}
      <Modal transparent={true} visible={showScheduledModal} animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Scheduled Deliveries</Text>
            {orders.filter((o) => o.status === "pending").length === 0 ? (
              <Text>No scheduled deliveries.</Text>
            ) : (
              orders
                .filter((o) => o.status === "pending")
                .map((order) => (
                  <View key={order.id} style={styles.pickupItem}>
                    <Text>
                      Order #{order.id}: {order.quantity} x Product {order.productId}
                    </Text>
                  </View>
                ))
            )}
            <TouchableOpacity style={styles.modalCloseButton} onPress={() => setShowScheduledModal(false)}>
              <Text style={styles.modalCloseButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity onPress={() => Alert.alert("About Us", "We connect farmers with consumers directly!")}>
          <Text style={styles.footerText}>About Us</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => Alert.alert("Contact Us", "Email: support@farmersmarket.com")}>
          <Text style={styles.footerText}>| Contact Us |</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => Alert.alert("Terms & Conditions", "These are our terms and conditions.")}>
          <Text style={styles.footerText}>Terms & Conditions</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E6F4C8",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#28A745",
    padding: 20,
  },
  headerTitle: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "bold",
  },
  iconContainer: {
    flexDirection: "row",
  },
  iconButton: {
    backgroundColor: "#FFA500",
    padding: 10,
    borderRadius: 8,
    marginLeft: 10,
  },
  navMenu: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  navItem: {
    padding: 10,
    marginRight: 10,
  },
  navText: {
    color: "#333",
    fontSize: 16,
  },
  activeNavItem: {
    borderBottomWidth: 2,
    borderBottomColor: "#28A745",
  },
  activeNavText: {
    color: "#28A745",
    fontWeight: "bold",
  },
  mainContent: {
    flex: 1,
    padding: 10,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  homeText: {
    fontSize: 16,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  summaryCard: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    padding: 15,
    marginTop: 10,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  summaryItem: {
    fontSize: 14,
    marginBottom: 5,
  },
  // alertItem: {
  //   color: "#FF4136",
  //   fontSize: 14,
  //   marginBottom: 5,
  // },
  growingHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  
  addGrowingButton: {
    padding: 5,
  },
  
  growingItemCard: {
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
  },
  
  growingItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  
  growingItemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  
  growingItemQuantity: {
    fontSize: 14,
    color: '#666',
  },
  
  growingItemDates: {
    marginBottom: 8,
  },
  
  dateText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  
  growingItemNotes: {
    fontSize: 14,
    color: '#666',
    fontStyle: 'italic',
  },
  
  noItemsText: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic',
    marginTop: 10,
  },
  
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
    marginLeft: 4,
  },
  
  notesInput: {
    height: 100,
    textAlignVertical: 'top',
  },


  searchBar: {
    backgroundColor: "#FFF",
    padding: 10,
    borderRadius: 8,
    marginBottom: 20,
    fontSize: 16,
  },
  noResultsText: {
    textAlign: "center",
    fontSize: 18,
    fontWeight: "bold",
    color: "#555",
  },
  productCard: {
    flexDirection: "row",
    backgroundColor: "#FFF",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: "center",
  },
  productImage: {
    width: 60,
    height: 60,
    marginRight: 15,
    borderRadius: 8,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: "bold",
  },
  productPrice: {
    fontSize: 16,
    color: "#28A745",
  },
  productCount: {
    fontSize: 14,
    color: "#555",
  },
  cardButtonContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 10,
  },
  cardButton: {
    padding: 5,
    borderRadius: 5,
    marginLeft: 5,
  },
  editButton: {
    backgroundColor: "#FFC107",
  },
  deleteButton: {
    backgroundColor: "#DC3545",
  },
  discountButton: {
    backgroundColor: "#FF4136",
  },
  removeDiscountButton: {
    backgroundColor: "#0074D9",
  },
  discountSticker: {
    position: "absolute",
    top: 5,
    right: 5,
    backgroundColor: "#FF4136",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  discountText: {
    color: "#FFF",
    fontSize: 12,
    fontWeight: "bold",
  },
  addNewButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#28A745",
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
  },
  addNewText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
    marginLeft: 10,
  },
  aiContainer: {
    padding: 15,
  },
  aiText: {
    fontSize: 16,
    marginBottom: 15,
  },
  aiCard: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    padding: 15,
    marginTop: 10,
  },
  aiInsight: {
    fontSize: 14,
    marginBottom: 10,
  },
  weatherTabCard: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
  },
  weatherTabTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  orderItem: {
    fontSize: 14,
    marginBottom: 5,
  },
  stockItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  setLimitButton: {
    backgroundColor: "#0074D9",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  setLimitButtonText: {
    color: "#FFF",
    fontSize: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-start", 
    alignItems: "center",
    paddingTop: 140, 
  },
  modalView: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    width: "80%",
  },
  modalContent: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    width: "80%",
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
  },
  imagePicker: {
    width: "50%",
    aspectRatio: 1,
    marginBottom: 15,
  },
  modalImage: {
    width: "100%",
    height: "100%",
    borderRadius: 10,
  },
  placeholderImage: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f0f0f0",
  },
  placeholderText: {
    fontSize: 14,
    color: "#888",
    marginTop: 5,
  },
  modalInput: {
    backgroundColor: '#fff',

    width: "100%",
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  modalButtonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    width: "45%",
  },
  cancelButton: {
    backgroundColor: "#DC3545",
  },
  saveButton: {
    backgroundColor: "#28A745",
  },
  modalButtonText: {
    color: "white",
    fontWeight: "bold",
  },
  modalCloseButton: {
    marginTop: 10,
    padding: 10,
    backgroundColor: "#FF4C4C",
    borderRadius: 5,
  },
  modalCloseButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
  pickupItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
    width: "100%",
  },
  footer: { 
    flexDirection: "row", 
    justifyContent: "center", 
    backgroundColor: "#FFA500", 
    padding: 10, 
    borderRadius: 10, 
    marginTop: 20 ,
    marginRight: 10,
    marginLeft: 10
  },

  footerText: { 
    color: "#FFF", 
    fontSize: 14, 
    marginHorizontal: 5 },
    weatherCard: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: 20,
    },
    weatherIcon: {
      width: 80, // Increased icon size
      height: 80,
      marginRight: 15,
    },
    weatherTemp: {
      fontSize: 30,
      fontWeight: "bold",
    },
    weatherDescription: {
      fontSize: 18,
    },
    weatherAlerts: {
      marginTop: 20, // Added margin
    },
    weatherAlertTitle: {
      fontSize: 18,
      fontWeight: "bold",
      marginBottom: 10,
    },
    weatherAlert: {
      color: "red",
      marginBottom: 5,
      fontSize: 16, 
    },
    weatherContainer: {
      flex: 1,
      padding: 15,
    },
    currentWeatherCard: {
      backgroundColor: '#FFF',
      borderRadius: 12,
      padding: 15,
      marginBottom: 15,
      elevation: 3,
    },
    weatherInfo: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 10,
    },
    weatherDetails: {
      marginTop: 20, 
      fontSize: 16,  
      marginLeft: 15,
    },
    temperature: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 5,
    },
    humidity: {
      fontSize: 16,
      color: '#666',
    },
    windSpeed: {
      fontSize: 16,
      color: '#666',
    },
    alertCard: {
      backgroundColor: '#FFF',
      borderRadius: 12,
      padding: 15,
      marginBottom: 15,
      elevation: 3,
    },
    cardTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      marginBottom: 15,
      flexDirection: 'row',
      alignItems: 'center',
    },
    cardIcon: {
      marginRight: 10,
    },
    alertItem: {
      backgroundColor: '#FFF5F5',
      borderRadius: 8,
      padding: 12,
      marginBottom: 10,
      borderLeftWidth: 4,
      borderLeftColor: '#FF4136',
    },
    alertTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      marginBottom: 5,
      color: '#FF4136',
    },
    alertDescription: {
      fontSize: 14,
      color: '#666',
    },
    cropRecommendationCard: {
      backgroundColor: '#FFF',
      borderRadius: 12,
      padding: 15,
      marginBottom: 15,
      elevation: 3,
    },
    recommendationItem: {
      backgroundColor: '#F0FFF4',
      borderRadius: 8,
      padding: 12,
      marginBottom: 10,
      borderLeftWidth: 4,
      borderLeftColor: '#28A745',
    },
    cropType: {
      fontSize: 16,
      fontWeight: 'bold',
      color: '#28A745',
      marginBottom: 5,
    },
    recommendationText: {
      fontSize: 14,
      color: '#666',
      lineHeight: 20,
    },
    forecastCard: {
      backgroundColor: '#FFF',
      borderRadius: 12,
      padding: 15,
      marginBottom: 15,
      elevation: 3,
    },
    forecastContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingHorizontal: 10,
    },
    forecastDay: {
      alignItems: 'center',
      flex: 1,
    },
    dayText: {
      fontSize: 16,
      fontWeight: 'bold',
      marginBottom: 8,
    },
    tempText: {
      fontSize: 18,
      fontWeight: 'bold',
      marginTop: 8,
    },
    weatherText: {
      fontSize: 14,
      color: '#666',
      marginTop: 4,
    },
  })