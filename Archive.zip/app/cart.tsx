import React, { useState } from "react";
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet } from "react-native";
import { useRouter } from "expo-router";

export default function CartScreen() {
  const router = useRouter();
  
  // Sample cart items (Later, this should be managed with global state or Context API)
  const [cartItems, setCartItems] = useState([
    { id: "1", name: "Fresh Apples", price: 2.99, quantity: 2, image: require("../assets/products/apple.jpg") },
    { id: "2", name: "Organic Carrots", price: 1.99, quantity: 1, image: require("../assets/products/carrot.jpg") },
    { id: "3", name: "Imperfect Tomatoes", price: 1.49, quantity: 3, image: require("../assets/products/tomato.jpg") },
  ]);

  // Calculate total amount
  const totalAmount = cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);

  // Function to remove an item from the cart
  const removeItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  return (
    <View style={styles.container}>
      {/* Back Button to go back to User Page */}
      {/* <TouchableOpacity style={styles.backButton} onPress={() => router.push("/User")}>
        <Text style={styles.backButtonText}>← Back</Text>
      </TouchableOpacity> */}

      <Text style={styles.title}>🛒 Your Cart</Text>

      {/* Cart Items List */}
      {cartItems.length > 0 ? (
        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.cartItem}>
              <Image source={item.image} style={styles.image} />
              <View style={styles.itemDetails}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemPrice}>${item.price.toFixed(2)} x {item.quantity}</Text>
              </View>
              <TouchableOpacity onPress={() => removeItem(item.id)} style={styles.removeButton}>
                <Text style={styles.removeButtonText}>🗑</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      ) : (
        <Text style={styles.emptyCartText}>Your cart is empty. 🛍</Text>
      )}

      {/* Total Price */}
      <Text style={styles.totalText}>Total: ${totalAmount}</Text>

      {/* Continue Shopping Button */}
      <TouchableOpacity style={styles.checkoutButton} onPress={() => router.push("/user")}>
        <Text style={styles.checkoutButtonText}>Continue Shopping</Text>
      </TouchableOpacity>

      {/* Proceed to Checkout Button */}
      <TouchableOpacity style={styles.proceedButton} onPress={() => router.push("/checkout")}>
        <Text style={styles.proceedButtonText}>Proceed to Checkout</Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E6F4C8",
    padding: 20,
  },
  backButton: {
    position: "absolute",
    top: 40,
    left: 20,
  },
  backButtonText: {
    fontSize: 16,
    color: "#007AFF",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    marginTop: 50,
  },
  cartItem: {
    flexDirection: "row",
    backgroundColor: "#FFF",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: "center",
  },
  image: {
    width: 60,
    height: 60,
    marginRight: 15,
  },
  itemDetails: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: "bold",
  },
  itemPrice: {
    fontSize: 16,
    color: "#555",
  },
  removeButton: {
    backgroundColor: "#FF4C4C",
    padding: 8,
    borderRadius: 5,
  },
  removeButtonText: {
    color: "#FFF",
    fontSize: 16,
  },
  totalText: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 10,
  },
  checkoutButton: {
    backgroundColor: "#FFA500",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },
  checkoutButtonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  proceedButton: {
    backgroundColor: "#28A745",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 10,
  },
  proceedButtonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  emptyCartText: {
    fontSize: 18,
    textAlign: "center",
    marginVertical: 20,
  },
});
