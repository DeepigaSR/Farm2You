import React, { useState } from "react";
import { View, Text, TextInput, FlatList, Image, TouchableOpacity, StyleSheet, Alert, Modal } from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { auth } from "../firebaseConfig"; // Firebase for Signout
import { signOut } from "firebase/auth";

export default function UserPage() {
  const router = useRouter();

  // State for cart
  const [cart, setCart] = useState<Record<string, number>>({});

  // State for search input
  const [searchQuery, setSearchQuery] = useState<string>("");

  // State for scheduled pickups modal
  const [showScheduledModal, setShowScheduledModal] = useState(false);

  // Sample scheduled items
  const [scheduledItems, setScheduledItems] = useState([
    { id: "1", name: "Fresh Apples", date: "Feb 17, 2025", time: "10:00 AM" },
    { id: "2", name: "Organic Carrots", date: "Feb 18, 2025", time: "11:30 AM" }
  ]);

  // Sample product list
  const products = [
    { id: "1", name: "Fresh Apples", price: 2.99, image: require("../assets/products/apple.jpg") },
    { id: "2", name: "Organic Carrots", price: 1.99, image: require("../assets/products/carrot.jpg") },
    { id: "3", name: "Imperfect Tomatoes", price: 1.49, image: require("../assets/products/tomato.jpg") },
    { id: "4", name: "Regular Bananas", price: 1.79, image: require("../assets/products/banana.jpg") },
    { id: "5", name: "Brown Egg", price: 3.99, image: require("../assets/products/egg.jpg") },
    { id: "6", name: "Fresh Spinach", price: 1.29, image: require("../assets/products/spinach.jpg") },
    { id: "7", name: "Juicy Oranges", price: 2.49, image: require("../assets/products/oranges.jpg") },
    { id: "8", name: "Sweet Strawberries", price: 4.99, image: require("../assets/products/strawberry.jpg") },
    { id: "9", name: "Red Cherries", price: 5.49, image: require("../assets/products/cherry.jpg") },
  ];

  // Function to update cart quantity
  const updateCart = (id: string, change: number) => {
    setCart((prevCart) => ({
      ...prevCart,
      [id]: Math.max((prevCart[id] || 0) + change, 0),
    }));
  };

  // Total items in cart
  const totalCartItems = Object.values(cart).reduce((acc, qty) => acc + qty, 0);

  // Filtered products based on search query
  const filteredProducts = products.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Signout Function
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      router.replace("/login"); // Redirect to login
    } catch (error) {
      Alert.alert("Sign Out Failed", "Something went wrong. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      {/* Header with Welcome Text, Cart, Scheduled Items Icon, and Sign Out */}
      <View style={styles.header}>
        {/* Back Button to Login
        <TouchableOpacity style={styles.backButton} onPress={() => router.replace("/auth/login")}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity> */}

        <Text style={styles.welcomeText}>Welcome, Janet!</Text>

        <View style={styles.iconContainer}>
          {/* Cart Icon */}
          <TouchableOpacity style={styles.iconButton} onPress={() => router.push("/cart")}>
            <Ionicons name="cart" size={24} color="white" />
            {totalCartItems > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{totalCartItems}</Text>
              </View>
            )}
          </TouchableOpacity>

          {/* Scheduled Items Icon */}
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowScheduledModal(true)}>
            <Ionicons name="calendar" size={24} color="white" />
          </TouchableOpacity>

          {/* Sign Out Button */}
          <TouchableOpacity style={styles.iconButton} onPress={handleSignOut}>
            <Ionicons name="log-out" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Search Bar */}
      <TextInput
        style={styles.searchBar}
        placeholder="Search for products..."
        placeholderTextColor="#FFA500"
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      {/* Products List */}
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.productCard}>
            <Image source={item.image} style={styles.productImage} />
            <View>
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
              <View style={styles.cartButtons}>
                <TouchableOpacity onPress={() => updateCart(item.id, -1)} style={styles.button}>
                  <Text style={styles.buttonText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.counterValue}>{cart[item.id] || 0}</Text>
                <TouchableOpacity onPress={() => updateCart(item.id, 1)} style={styles.button}>
                  <Text style={styles.buttonText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      />

      {/* Scheduled Items Modal */}
      <Modal transparent={true} visible={showScheduledModal} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Scheduled Pickups</Text>
            {scheduledItems.length === 0 ? (
              <Text>No scheduled pickups.</Text>
            ) : (
              scheduledItems.map((item) => (
                <View key={item.id} style={styles.pickupItem}>
                  <Text>{item.name}</Text>
                  <Text>{item.date} at {item.time}</Text>
                </View>
              ))
            )}
            <TouchableOpacity style={styles.modalCloseButton} onPress={() => setShowScheduledModal(false)}>
              <Text style={styles.modalCloseButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity onPress={() => Alert.alert("About Us", "We connect farmers with consumers directly!")}>
          <Text style={styles.footerText}>About Us</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => Alert.alert("Contact Us", "Email: support@farmersmarket.com")}>
          <Text style={styles.footerText}>| Contact Us |</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => Alert.alert("Terms & Conditions", "By using this platform, you agree to abide by our terms and conditions. Please be respectful to others.")}>
          <Text style={styles.footerText}>Terms & Conditions</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E6F4C8", padding: 20 },

  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20, marginTop: 50 },

  welcomeText: { fontSize: 22, fontWeight: "bold" },

  iconContainer: { flexDirection: "row" },

  iconButton: { backgroundColor: "#FFA500", padding: 10, borderRadius: 8, marginLeft: 10 },

  cartBadge: { position: "absolute", top: -5, right: -5, backgroundColor: "red", borderRadius: 10, paddingHorizontal: 6 },

  cartBadgeText: { color: "white", fontSize: 12, fontWeight: "bold" },

  searchBar: { backgroundColor: "#FFF", padding: 10, borderRadius: 8, marginBottom: 20, fontSize: 16 },

  noResultsText: { textAlign: "center", fontSize: 18, fontWeight: "bold", color: "#555" },

  productCard: { 
    flexDirection: "row", 
    backgroundColor: "#FFF", 
    padding: 15, 
    borderRadius: 10, 
    marginBottom: 15, 
    alignItems: "center" 
  },

  productImage: { width: 60, height: 60, marginRight: 15 },

  productName: { fontSize: 18, fontWeight: "bold" },

  productPrice: { fontSize: 16, color: "#555" },

  cartButtons: { flexDirection: "row", alignItems: "center", marginTop: 5 },

  button: { backgroundColor: "#FFA500", padding: 8, borderRadius: 5, marginHorizontal: 5 },

  buttonText: { color: "#FFF", fontSize: 18, fontWeight: "bold" },

  counterValue: { fontSize: 18, fontWeight: "bold" },

  modalContainer: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.5)" },

  modalContent: { backgroundColor: "white", padding: 20, borderRadius: 10, width: "80%", alignItems: "center" },

  modalTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 10 },

  modalCloseButton: { marginTop: 10, padding: 10, backgroundColor: "#FF4C4C", borderRadius: 5 },

  modalCloseButtonText: { color: "white", fontSize: 16, fontWeight: "bold" },

  pickupItem: { padding: 10, borderBottomWidth: 1, borderBottomColor: "#ccc", width: "100%", textAlign: "center" },

  footer: { flexDirection: "row", justifyContent: "center", backgroundColor: "#FFA500", padding: 10, borderRadius: 10, marginTop: 20 },

  footerText: { color: "#FFF", fontSize: 14, marginHorizontal: 5 },
  backButton: { padding: 10, marginRight: 10 },
 });
